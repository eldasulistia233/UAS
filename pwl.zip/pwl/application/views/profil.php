<?php $this->load->view('header'); ?>
        
<div class="utama">
    <div class="kiri">
        <h3>Profil Lulusan</h3>
<table border="1" cellspacing="0" align="left">
<tbody>
<tr>
<td>
<p><strong>No.</strong></p>
</td>
<td>
<p><strong>PROFIL</strong></p>
</td>
<td>
<p><strong>CAPAIAN PEMBELAJARAN</strong></p>
</td>
</tr>
<tr>
<td>
<ol>
</ol>
</td>
<td>
<p>Guru Teknologi Informasi dan Komunikasi (TIK) / Guru TIK</p>
</td>
<td colspan="2">
<ol>
<li>Menghasilkan&nbsp;Guru&nbsp;TIK yang berkualitas</li>
<li>Guru TIK yang memiliki kompetensi yang tinggi di bidang teknologi informasi dan komunikasi</li>
<li>Guru TIK yang dapat bersaing pada bursa kerja nasionla serta menjadi kreator dalam menciptakan lapangan kerja baru dengan menguasai TIK</li>
<li>Guru TIK yang mampu menyelesaikan masalah di bidang pendidikan informatika</li>
</ol>
</td>
</tr>
<tr>
<td>
<ol start="5">
</ol>
</td>
<td>
<p>Sistem Analis dan Perancang Sistem Informasi</p>
</td>
<td colspan="2">
<ol>
<li>Menjadi sistem analis dan perancang sistem informasi yang&nbsp;ahli di bidang Rekayasa Perangkat Lunak (RPL)</li>
<li>Sistem analis dan perancang sistem informasi yang mampu menrencanakan, menganalisa sistem, membangun dan merancang software aplication dengan metode analisis dan perancangan sistem informasi</li>
<li>Sistem analisi dan perancang sistem informasi yang mampu membangun sistem informasi dengan menggunakan bahasa pemrograman yang didukung oleh teknologi informasi</li>
<li>Sistem analis dan perancang sistem informasi yang mampu membangun sistem informasi yang terbaru untuk manajemen (user) dalam menyelesaikan masalah industri atau organisasi sesuai dengan perkembangan organisasi pengguna</li>
</ol>
</td>
</tr>
<tr>
<td>
<ol start="6">
</ol>
</td>
<td>
<p>Administrator Server Terintegrasi</p>
</td>
<td colspan="2">
<ol>
<li>Administrator server terintegrasi yang mampu menginstalasi perangkat komputer dan mengkonfigurasikan perangkat jaringan lokal &ndash; Local Area Network, perngkat jaringan luas &ndash; Wide Area Network</li>
<li>Administrator server terintegrasi yang mampu merancang sistem keamanan jaringan, mengelola dan mengadministrasi jaringan pada suatu industri atau organisasi pengguna</li>
<li>Administrator server terintegrasi yang mampu merancang sistem keamanan jaringan mengelola dan mengadministrasi jaringan pada suatu industri atau organisasi pengguna</li>
</ol>
</td>
</tr>
<tr>
<td>
<ol start="7">
</ol>
</td>
<td>
<p>Animator, Desainer Grafis dan Digital Illustrator</p>
</td>
<td colspan="2">
<ol>
<li>Animator, desainer grafis dan digital illustrator yang ahli dan kompeten di bidang multimedia mulai dari media audio, video, teks, grafik dan animasi</li>
<li>Animator, desainer grafis dan digital illustrator yang ahlimenganalisa konsep pengembangan desain, desain mutimedia, manajemen produksi multimedia</li>
<li>Animator, desainer grafis dan digital illustrator yang ahli sebagai animator, web designer, videographer, art director, photographer, storyboarder dan digital illustrator dalam melayani kebutuhan industri atau organisasi pengguna</li>
</ol>
</td>
</tr>
</tbody>
</table>
    </div>
    <?php $this->load->view('kanan'); ?>
</div>
    
<?php $this->load->view('footer'); ?>

