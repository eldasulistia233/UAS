	<div class="footer">
		&copy 2020 - STKIP PGRI Sumatera Barat
	</div>

	</body>
</html>
