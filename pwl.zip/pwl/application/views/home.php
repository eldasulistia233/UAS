<?php $this->load->view('header'); ?>
		
<div class="utama">
	<div class="kiri">
		<h3>Penerimaan Mahasiswa Baru</h3>
		<p>Selamat datang di situs Penerimaan Mahasiswa Baru Pendidikan Teknik Informatika STKIP PGRI Sumatera Barat.</p>

		<p>Langkah-langkah melakukan pendaftaran:</p>
		<ol>
			<li>Buat akun pada menu <strong>Buat Akun</strong></li>
			<li>Setelah proses pendaftaran akun selesai, silahkan login pada menu <strong>Login</strong></li>
			<li>Kemudian lengkapi formulir pendaftaran yang telah disediakan</li>
			<li>Cetak bukti pendaftaran</li>

		</ol>
	</div>
	<?php $this->load->view('kanan'); ?>
</div>
	
<?php $this->load->view('footer'); ?>

